/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
import org.hibernate.Query;
import org.hibernate.LockMode;
import java.util.List;

public class PeliculaDAO {
	public static Pelicula loadPeliculaByORMID(int id_pelicula) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadPeliculaByORMID(session, id_pelicula);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula getPeliculaByORMID(int id_pelicula) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getPeliculaByORMID(session, id_pelicula);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByORMID(int id_pelicula, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadPeliculaByORMID(session, id_pelicula, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula getPeliculaByORMID(int id_pelicula, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getPeliculaByORMID(session, id_pelicula, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByORMID(PersistentSession session, int id_pelicula) throws PersistentException {
		try {
			return (Pelicula) session.load(Pelicula.class, new Integer(id_pelicula));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula getPeliculaByORMID(PersistentSession session, int id_pelicula) throws PersistentException {
		try {
			return (Pelicula) session.get(Pelicula.class, new Integer(id_pelicula));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByORMID(PersistentSession session, int id_pelicula, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Pelicula) session.load(Pelicula.class, new Integer(id_pelicula), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula getPeliculaByORMID(PersistentSession session, int id_pelicula, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Pelicula) session.get(Pelicula.class, new Integer(id_pelicula), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryPelicula(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return queryPelicula(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryPelicula(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return queryPelicula(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula[] listPeliculaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listPeliculaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula[] listPeliculaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listPeliculaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryPelicula(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Pelicula as Pelicula");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryPelicula(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Pelicula as Pelicula");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Pelicula", lockMode);
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula[] listPeliculaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		try {
			List list = queryPelicula(session, condition, orderBy);
			return (Pelicula[]) list.toArray(new Pelicula[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula[] listPeliculaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			List list = queryPelicula(session, condition, orderBy, lockMode);
			return (Pelicula[]) list.toArray(new Pelicula[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadPeliculaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadPeliculaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Pelicula[] peliculas = listPeliculaByQuery(session, condition, orderBy);
		if (peliculas != null && peliculas.length > 0)
			return peliculas[0];
		else
			return null;
	}
	
	public static Pelicula loadPeliculaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Pelicula[] peliculas = listPeliculaByQuery(session, condition, orderBy, lockMode);
		if (peliculas != null && peliculas.length > 0)
			return peliculas[0];
		else
			return null;
	}
	
	public static java.util.Iterator iteratePeliculaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iteratePeliculaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iteratePeliculaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iteratePeliculaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iteratePeliculaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Pelicula as Pelicula");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iteratePeliculaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Pelicula as Pelicula");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Pelicula", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula createPelicula() {
		return new Pelicula();
	}
	
	public static boolean save(Pelicula pelicula) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().saveObject(pelicula);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(Pelicula pelicula) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().deleteObject(pelicula);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Pelicula pelicula)throws PersistentException {
		try {
			if (pelicula.getId_director() != null) {
				pelicula.getId_director().setPelicula(null);
			}
			
			Categoria[] lId_categorias = pelicula.id_categoria.toArray();
			for(int i = 0; i < lId_categorias.length; i++) {
				lId_categorias[i].id_pelicula.remove(pelicula);
			}
			if (pelicula.getFuncion() != null) {
				pelicula.getFuncion().setId_pelicula(null);
			}
			
			return delete(pelicula);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Pelicula pelicula, org.orm.PersistentSession session)throws PersistentException {
		try {
			if (pelicula.getId_director() != null) {
				pelicula.getId_director().setPelicula(null);
			}
			
			Categoria[] lId_categorias = pelicula.id_categoria.toArray();
			for(int i = 0; i < lId_categorias.length; i++) {
				lId_categorias[i].id_pelicula.remove(pelicula);
			}
			if (pelicula.getFuncion() != null) {
				pelicula.getFuncion().setId_pelicula(null);
			}
			
			try {
				session.delete(pelicula);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(Pelicula pelicula) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().refresh(pelicula);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(Pelicula pelicula) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().evict(pelicula);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Pelicula loadPeliculaByCriteria(PeliculaCriteria peliculaCriteria) {
		Pelicula[] peliculas = listPeliculaByCriteria(peliculaCriteria);
		if(peliculas == null || peliculas.length == 0) {
			return null;
		}
		return peliculas[0];
	}
	
	public static Pelicula[] listPeliculaByCriteria(PeliculaCriteria peliculaCriteria) {
		return peliculaCriteria.listPelicula();
	}
}
