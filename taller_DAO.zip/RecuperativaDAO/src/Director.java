
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
public class Director {
	public Director() {
	}
	
	private int id_director;
	
	private String nombre;
	
	private String nacionalidad;
	
	private Pelicula pelicula;
	
	private void setId_director(int value) {
		this.id_director = value;
	}
	
	public int getId_director() {
		return id_director;
	}
	
	public int getORMID() {
		return getId_director();
	}
	
	public void setNombre(String value) {
		this.nombre = value;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNacionalidad(String value) {
		this.nacionalidad = value;
	}
	
	public String getNacionalidad() {
		return nacionalidad;
	}
	
	public void setPelicula(Pelicula value) {
		if (this.pelicula != value) {
			Pelicula lpelicula = this.pelicula;
			this.pelicula = value;
			if (value != null) {
				pelicula.setId_director(this);
			}
			if (lpelicula != null && lpelicula.getId_director() == this) {
				lpelicula.setId_director(null);
			}
		}
	}
	
	public Pelicula getPelicula() {
		return pelicula;
	}
	
	public String toString() {
		return String.valueOf(getId_director());
	}
	
}
