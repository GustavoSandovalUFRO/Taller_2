
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class PeliculaCriteria extends AbstractORMCriteria {
	public final StringExpression titulo;
	public final IntegerExpression año;
	public final IntegerExpression id_pelicula;
	public final IntegerExpression duracion;
	public final IntegerExpression id_directorId;
	public final AssociationExpression id_director;
	public final StringExpression imagen;
	public final CollectionExpression id_categoria;
	public final IntegerExpression funcionId;
	public final AssociationExpression funcion;
	
	public PeliculaCriteria(Criteria criteria) {
		super(criteria);
		titulo = new StringExpression("titulo", this);
		año = new IntegerExpression("año", this);
		id_pelicula = new IntegerExpression("id_pelicula", this);
		duracion = new IntegerExpression("duracion", this);
		id_directorId = new IntegerExpression("id_director.id_director", this);
		id_director = new AssociationExpression("id_director", this);
		imagen = new StringExpression("imagen", this);
		id_categoria = new CollectionExpression("ORM_Id_categoria", this);
		funcionId = new IntegerExpression("funcion.id_pelicula", this);
		funcion = new AssociationExpression("funcion", this);
	}
	
	public PeliculaCriteria(PersistentSession session) {
		this(session.createCriteria(Pelicula.class));
	}
	
	public PeliculaCriteria() throws PersistentException {
		this(TallerDAOPersistentManager.instance().getSession());
	}
	
	public DirectorCriteria createId_directorCriteria() {
		return new DirectorCriteria(createCriteria("id_director"));
	}
	
	public CategoriaCriteria createId_categoriaCriteria() {
		return new CategoriaCriteria(createCriteria("ORM_Id_categoria"));
	}
	
	public FuncionCriteria createFuncionCriteria() {
		return new FuncionCriteria(createCriteria("funcion"));
	}
	
	public Pelicula uniquePelicula() {
		return (Pelicula) super.uniqueResult();
	}
	
	public Pelicula[] listPelicula() {
		java.util.List list = super.list();
		return (Pelicula[]) list.toArray(new Pelicula[list.size()]);
	}
}

