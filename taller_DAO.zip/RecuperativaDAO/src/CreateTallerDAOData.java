/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
public class CreateTallerDAOData {
	public void createTestData() throws PersistentException {
		PersistentTransaction t = TallerDAOPersistentManager.instance().getSession().beginTransaction();
		try {
			Pelicula pelicula = PeliculaDAO.createPelicula();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : funcion, id_categoria, id_director
			PeliculaDAO.save(pelicula);
			Director director = DirectorDAO.createDirector();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : pelicula
			DirectorDAO.save(director);
			Sala sala = SalaDAO.createSala();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : funcion, codigo_sala
			SalaDAO.save(sala);
			Funcion funcion = FuncionDAO.createFuncion();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : id_pelicula, id_sala
			FuncionDAO.save(funcion);
			Categoria categoria = CategoriaDAO.createCategoria();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : id_pelicula
			CategoriaDAO.save(categoria);
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public static void main(String[] args) {
		try {
			CreateTallerDAOData createTallerDAOData = new CreateTallerDAOData();
			try {
				createTallerDAOData.createTestData();
			}
			finally {
				TallerDAOPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
