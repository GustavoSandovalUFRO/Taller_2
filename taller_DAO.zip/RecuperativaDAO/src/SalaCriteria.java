
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class SalaCriteria extends AbstractORMCriteria {
	public final IntegerExpression id_sala;
	public final StringExpression codigo_sala;
	public final IntegerExpression funcionId;
	public final AssociationExpression funcion;
	
	public SalaCriteria(Criteria criteria) {
		super(criteria);
		id_sala = new IntegerExpression("id_sala", this);
		codigo_sala = new StringExpression("codigo_sala", this);
		funcionId = new IntegerExpression("funcion.id_sala", this);
		funcion = new AssociationExpression("funcion", this);
	}
	
	public SalaCriteria(PersistentSession session) {
		this(session.createCriteria(Sala.class));
	}
	
	public SalaCriteria() throws PersistentException {
		this(TallerDAOPersistentManager.instance().getSession());
	}
	
	public FuncionCriteria createFuncionCriteria() {
		return new FuncionCriteria(createCriteria("funcion"));
	}
	
	public Sala uniqueSala() {
		return (Sala) super.uniqueResult();
	}
	
	public Sala[] listSala() {
		java.util.List list = super.list();
		return (Sala[]) list.toArray(new Sala[list.size()]);
	}
}

