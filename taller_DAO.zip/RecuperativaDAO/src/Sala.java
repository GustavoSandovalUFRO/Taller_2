

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
public class Sala {
	public Sala() {
	}
	
	private int id_sala;
	
	private String codigo_sala;
	
	private Funcion funcion;
	
	private void setId_sala(int value) {
		this.id_sala = value;
	}
	
	public int getId_sala() {
		return id_sala;
	}
	
	public int getORMID() {
		return getId_sala();
	}
	
	public void setCodigo_sala(String value) {
		this.codigo_sala = value;
	}
	
	public String getCodigo_sala() {
		return codigo_sala;
	}
	
	public void setFuncion(Funcion value) {
		if (this.funcion != value) {
			Funcion lfuncion = this.funcion;
			this.funcion = value;
			if (value != null) {
				funcion.setId_sala(this);
			}
			if (lfuncion != null && lfuncion.getId_sala() == this) {
				lfuncion.setId_sala(null);
			}
		}
	}
	
	public Funcion getFuncion() {
		return funcion;
	}
	
	public String toString() {
		return String.valueOf(getId_sala());
	}
	
}
