
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
public class Pelicula {
	public Pelicula() {
	}
	
	private java.util.Set this_getSet (int key) {
		if (key == ORMConstants.KEY_PELICULA_ID_CATEGORIA) {
			return ORM_id_categoria;
		}
		
		return null;
	}
	
	private void this_setOwner(Object owner, int key) {
		if (key == ORMConstants.KEY_PELICULA_ID_DIRECTOR) {
			this.id_director = (Director) owner;
		}
		
		else if (key == ORMConstants.KEY_PELICULA_FUNCION) {
			this.funcion = (Funcion) owner;
		}
	}
	
	org.orm.util.ORMAdapter _ormAdapter = new org.orm.util.AbstractORMAdapter() {
		public java.util.Set getSet(int key) {
			return this_getSet(key);
		}
		
		public void setOwner(Object owner, int key) {
			this_setOwner(owner, key);
		}
		
	};
	
	private String titulo;
	
	private Integer año;
	
	private int id_pelicula;
	
	private Integer duracion;
	
	private Director id_director;
	
	private String imagen;
	
	private java.util.Set ORM_id_categoria = new java.util.HashSet();
	
	private Funcion funcion;
	
	public void setTitulo(String value) {
		this.titulo = value;
	}
	
	public String getTitulo() {
		return titulo;
	}
	
	public void setAño(int value) {
		setAño(new Integer(value));
	}
	
	public void setAño(Integer value) {
		this.año = value;
	}
	
	public Integer getAño() {
		return año;
	}
	
	private void setId_pelicula(int value) {
		this.id_pelicula = value;
	}
	
	public int getId_pelicula() {
		return id_pelicula;
	}
	
	public int getORMID() {
		return getId_pelicula();
	}
	
	public void setDuracion(int value) {
		setDuracion(new Integer(value));
	}
	
	public void setDuracion(Integer value) {
		this.duracion = value;
	}
	
	public Integer getDuracion() {
		return duracion;
	}
	
	public void setImagen(String value) {
		this.imagen = value;
	}
	
	public String getImagen() {
		return imagen;
	}
	
	public void setId_director(Director value) {
		if (this.id_director != value) {
			Director lid_director = this.id_director;
			this.id_director = value;
			if (value != null) {
				id_director.setPelicula(this);
			}
			if (lid_director != null && lid_director.getPelicula() == this) {
				lid_director.setPelicula(null);
			}
		}
	}
	
	public Director getId_director() {
		return id_director;
	}
	
	private void setORM_Id_categoria(java.util.Set value) {
		this.ORM_id_categoria = value;
	}
	
	private java.util.Set getORM_Id_categoria() {
		return ORM_id_categoria;
	}
	
	public final CategoriaSetCollection id_categoria = new CategoriaSetCollection(this, _ormAdapter, ORMConstants.KEY_PELICULA_ID_CATEGORIA, ORMConstants.KEY_CATEGORIA_ID_PELICULA, ORMConstants.KEY_MUL_MANY_TO_MANY);
	
	public void setFuncion(Funcion value) {
		if (this.funcion != value) {
			Funcion lfuncion = this.funcion;
			this.funcion = value;
			if (value != null) {
				funcion.setId_pelicula(this);
			}
			if (lfuncion != null && lfuncion.getId_pelicula() == this) {
				lfuncion.setId_pelicula(null);
			}
		}
	}
	
	public Funcion getFuncion() {
		return funcion;
	}
	
	public String toString() {
		return String.valueOf(getId_pelicula());
	}
	
}
