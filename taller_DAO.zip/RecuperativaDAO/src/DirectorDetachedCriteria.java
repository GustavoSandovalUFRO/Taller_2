
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class DirectorDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression id_director;
	public final StringExpression nombre;
	public final StringExpression nacionalidad;
	public final IntegerExpression peliculaId;
	public final AssociationExpression pelicula;
	
	public DirectorDetachedCriteria() {
		super(Director.class, DirectorCriteria.class);
		id_director = new IntegerExpression("id_director", this.getDetachedCriteria());
		nombre = new StringExpression("nombre", this.getDetachedCriteria());
		nacionalidad = new StringExpression("nacionalidad", this.getDetachedCriteria());
		peliculaId = new IntegerExpression("pelicula.id_director", this.getDetachedCriteria());
		pelicula = new AssociationExpression("pelicula", this.getDetachedCriteria());
	}
	
	public DirectorDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, DirectorCriteria.class);
		id_director = new IntegerExpression("id_director", this.getDetachedCriteria());
		nombre = new StringExpression("nombre", this.getDetachedCriteria());
		nacionalidad = new StringExpression("nacionalidad", this.getDetachedCriteria());
		peliculaId = new IntegerExpression("pelicula.id_director", this.getDetachedCriteria());
		pelicula = new AssociationExpression("pelicula", this.getDetachedCriteria());
	}
	
	public PeliculaDetachedCriteria createPeliculaCriteria() {
		return new PeliculaDetachedCriteria(createCriteria("pelicula"));
	}
	
	public Director uniqueDirector(PersistentSession session) {
		return (Director) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Director[] listDirector(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Director[]) list.toArray(new Director[list.size()]);
	}
}

