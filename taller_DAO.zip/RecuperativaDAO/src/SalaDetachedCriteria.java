/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class SalaDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression id_sala;
	public final StringExpression codigo_sala;
	public final IntegerExpression funcionId;
	public final AssociationExpression funcion;
	
	public SalaDetachedCriteria() {
		super(Sala.class, SalaCriteria.class);
		id_sala = new IntegerExpression("id_sala", this.getDetachedCriteria());
		codigo_sala = new StringExpression("codigo_sala", this.getDetachedCriteria());
		funcionId = new IntegerExpression("funcion.id_sala", this.getDetachedCriteria());
		funcion = new AssociationExpression("funcion", this.getDetachedCriteria());
	}
	
	public SalaDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, SalaCriteria.class);
		id_sala = new IntegerExpression("id_sala", this.getDetachedCriteria());
		codigo_sala = new StringExpression("codigo_sala", this.getDetachedCriteria());
		funcionId = new IntegerExpression("funcion.id_sala", this.getDetachedCriteria());
		funcion = new AssociationExpression("funcion", this.getDetachedCriteria());
	}
	
	public FuncionDetachedCriteria createFuncionCriteria() {
		return new FuncionDetachedCriteria(createCriteria("funcion"));
	}
	
	public Sala uniqueSala(PersistentSession session) {
		return (Sala) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Sala[] listSala(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Sala[]) list.toArray(new Sala[list.size()]);
	}
}

