/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
import org.hibernate.Query;
import org.hibernate.LockMode;
import java.util.List;

public class FuncionDAO {
	public static Funcion loadFuncionByORMID(int id_funcion) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadFuncionByORMID(session, id_funcion);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion getFuncionByORMID(int id_funcion) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getFuncionByORMID(session, id_funcion);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByORMID(int id_funcion, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadFuncionByORMID(session, id_funcion, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion getFuncionByORMID(int id_funcion, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getFuncionByORMID(session, id_funcion, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByORMID(PersistentSession session, int id_funcion) throws PersistentException {
		try {
			return (Funcion) session.load(Funcion.class, new Integer(id_funcion));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion getFuncionByORMID(PersistentSession session, int id_funcion) throws PersistentException {
		try {
			return (Funcion) session.get(Funcion.class, new Integer(id_funcion));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByORMID(PersistentSession session, int id_funcion, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Funcion) session.load(Funcion.class, new Integer(id_funcion), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion getFuncionByORMID(PersistentSession session, int id_funcion, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Funcion) session.get(Funcion.class, new Integer(id_funcion), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryFuncion(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return queryFuncion(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryFuncion(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return queryFuncion(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion[] listFuncionByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listFuncionByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion[] listFuncionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listFuncionByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryFuncion(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Funcion as Funcion");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryFuncion(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Funcion as Funcion");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Funcion", lockMode);
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion[] listFuncionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		try {
			List list = queryFuncion(session, condition, orderBy);
			return (Funcion[]) list.toArray(new Funcion[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion[] listFuncionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			List list = queryFuncion(session, condition, orderBy, lockMode);
			return (Funcion[]) list.toArray(new Funcion[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadFuncionByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadFuncionByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Funcion[] funcions = listFuncionByQuery(session, condition, orderBy);
		if (funcions != null && funcions.length > 0)
			return funcions[0];
		else
			return null;
	}
	
	public static Funcion loadFuncionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Funcion[] funcions = listFuncionByQuery(session, condition, orderBy, lockMode);
		if (funcions != null && funcions.length > 0)
			return funcions[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateFuncionByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iterateFuncionByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateFuncionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iterateFuncionByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateFuncionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Funcion as Funcion");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateFuncionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Funcion as Funcion");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Funcion", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion createFuncion() {
		return new Funcion();
	}
	
	public static boolean save(Funcion funcion) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().saveObject(funcion);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(Funcion funcion) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().deleteObject(funcion);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Funcion funcion)throws PersistentException {
		try {
			if (funcion.getId_sala() != null) {
				funcion.getId_sala().setFuncion(null);
			}
			
			if (funcion.getId_pelicula() != null) {
				funcion.getId_pelicula().setFuncion(null);
			}
			
			return delete(funcion);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Funcion funcion, org.orm.PersistentSession session)throws PersistentException {
		try {
			if (funcion.getId_sala() != null) {
				funcion.getId_sala().setFuncion(null);
			}
			
			if (funcion.getId_pelicula() != null) {
				funcion.getId_pelicula().setFuncion(null);
			}
			
			try {
				session.delete(funcion);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(Funcion funcion) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().refresh(funcion);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(Funcion funcion) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().evict(funcion);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Funcion loadFuncionByCriteria(FuncionCriteria funcionCriteria) {
		Funcion[] funcions = listFuncionByCriteria(funcionCriteria);
		if(funcions == null || funcions.length == 0) {
			return null;
		}
		return funcions[0];
	}
	
	public static Funcion[] listFuncionByCriteria(FuncionCriteria funcionCriteria) {
		return funcionCriteria.listFuncion();
	}
}
