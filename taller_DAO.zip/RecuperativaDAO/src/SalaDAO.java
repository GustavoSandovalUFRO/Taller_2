/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
import org.hibernate.Query;
import org.hibernate.LockMode;
import java.util.List;

public class SalaDAO {
	public static Sala loadSalaByORMID(int id_sala) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadSalaByORMID(session, id_sala);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala getSalaByORMID(int id_sala) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getSalaByORMID(session, id_sala);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByORMID(int id_sala, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadSalaByORMID(session, id_sala, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala getSalaByORMID(int id_sala, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return getSalaByORMID(session, id_sala, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByORMID(PersistentSession session, int id_sala) throws PersistentException {
		try {
			return (Sala) session.load(Sala.class, new Integer(id_sala));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala getSalaByORMID(PersistentSession session, int id_sala) throws PersistentException {
		try {
			return (Sala) session.get(Sala.class, new Integer(id_sala));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByORMID(PersistentSession session, int id_sala, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Sala) session.load(Sala.class, new Integer(id_sala), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala getSalaByORMID(PersistentSession session, int id_sala, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Sala) session.get(Sala.class, new Integer(id_sala), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List querySala(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return querySala(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List querySala(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return querySala(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala[] listSalaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listSalaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala[] listSalaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return listSalaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List querySala(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Sala as Sala");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List querySala(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Sala as Sala");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Sala", lockMode);
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala[] listSalaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		try {
			List list = querySala(session, condition, orderBy);
			return (Sala[]) list.toArray(new Sala[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala[] listSalaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			List list = querySala(session, condition, orderBy, lockMode);
			return (Sala[]) list.toArray(new Sala[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadSalaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return loadSalaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Sala[] salas = listSalaByQuery(session, condition, orderBy);
		if (salas != null && salas.length > 0)
			return salas[0];
		else
			return null;
	}
	
	public static Sala loadSalaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Sala[] salas = listSalaByQuery(session, condition, orderBy, lockMode);
		if (salas != null && salas.length > 0)
			return salas[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateSalaByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iterateSalaByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateSalaByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = TallerDAOPersistentManager.instance().getSession();
			return iterateSalaByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateSalaByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Sala as Sala");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateSalaByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Sala as Sala");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Sala", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala createSala() {
		return new Sala();
	}
	
	public static boolean save(Sala sala) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().saveObject(sala);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(Sala sala) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().deleteObject(sala);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Sala sala)throws PersistentException {
		try {
			if (sala.getFuncion() != null) {
				sala.getFuncion().setId_sala(null);
			}
			
			return delete(sala);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Sala sala, org.orm.PersistentSession session)throws PersistentException {
		try {
			if (sala.getFuncion() != null) {
				sala.getFuncion().setId_sala(null);
			}
			
			try {
				session.delete(sala);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(Sala sala) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().refresh(sala);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(Sala sala) throws PersistentException {
		try {
			TallerDAOPersistentManager.instance().getSession().evict(sala);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Sala loadSalaByCriteria(SalaCriteria salaCriteria) {
		Sala[] salas = listSalaByCriteria(salaCriteria);
		if(salas == null || salas.length == 0) {
			return null;
		}
		return salas[0];
	}
	
	public static Sala[] listSalaByCriteria(SalaCriteria salaCriteria) {
		return salaCriteria.listSala();
	}
}
