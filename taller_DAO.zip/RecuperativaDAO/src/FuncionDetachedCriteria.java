

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class FuncionDetachedCriteria extends AbstractORMDetachedCriteria {
	public final TimeExpression hora;
	public final IntegerExpression id_funcion;
	public final IntegerExpression id_salaId;
	public final AssociationExpression id_sala;
	public final IntegerExpression id_peliculaId;
	public final AssociationExpression id_pelicula;
	
	public FuncionDetachedCriteria() {
		super(Funcion.class, FuncionCriteria.class);
		hora = new TimeExpression("hora", this.getDetachedCriteria());
		id_funcion = new IntegerExpression("id_funcion", this.getDetachedCriteria());
		id_salaId = new IntegerExpression("id_sala.id_sala", this.getDetachedCriteria());
		id_sala = new AssociationExpression("id_sala", this.getDetachedCriteria());
		id_peliculaId = new IntegerExpression("id_pelicula.id_pelicula", this.getDetachedCriteria());
		id_pelicula = new AssociationExpression("id_pelicula", this.getDetachedCriteria());
	}
	
	public FuncionDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, FuncionCriteria.class);
		hora = new TimeExpression("hora", this.getDetachedCriteria());
		id_funcion = new IntegerExpression("id_funcion", this.getDetachedCriteria());
		id_salaId = new IntegerExpression("id_sala.id_sala", this.getDetachedCriteria());
		id_sala = new AssociationExpression("id_sala", this.getDetachedCriteria());
		id_peliculaId = new IntegerExpression("id_pelicula.id_pelicula", this.getDetachedCriteria());
		id_pelicula = new AssociationExpression("id_pelicula", this.getDetachedCriteria());
	}
	
	public SalaDetachedCriteria createId_salaCriteria() {
		return new SalaDetachedCriteria(createCriteria("id_sala"));
	}
	
	public PeliculaDetachedCriteria createId_peliculaCriteria() {
		return new PeliculaDetachedCriteria(createCriteria("id_pelicula"));
	}
	
	public Funcion uniqueFuncion(PersistentSession session) {
		return (Funcion) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Funcion[] listFuncion(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Funcion[]) list.toArray(new Funcion[list.size()]);
	}
}

