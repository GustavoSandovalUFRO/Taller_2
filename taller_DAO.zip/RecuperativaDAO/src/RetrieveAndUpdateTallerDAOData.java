/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
public class RetrieveAndUpdateTallerDAOData {
	public void retrieveAndUpdateTestData() throws PersistentException {
		PersistentTransaction t = TallerDAOPersistentManager.instance().getSession().beginTransaction();
		try {
			Pelicula pelicula = PeliculaDAO.loadPeliculaByQuery(null, null);
			// Update the properties of the persistent object
			PeliculaDAO.save(pelicula);
			Director director = DirectorDAO.loadDirectorByQuery(null, null);
			// Update the properties of the persistent object
			DirectorDAO.save(director);
			Sala sala = SalaDAO.loadSalaByQuery(null, null);
			// Update the properties of the persistent object
			SalaDAO.save(sala);
			Funcion funcion = FuncionDAO.loadFuncionByQuery(null, null);
			// Update the properties of the persistent object
			FuncionDAO.save(funcion);
			Categoria categoria = CategoriaDAO.loadCategoriaByQuery(null, null);
			// Update the properties of the persistent object
			CategoriaDAO.save(categoria);
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public void retrieveByCriteria() throws PersistentException {
		System.out.println("Retrieving Pelicula by PeliculaCriteria");
		PeliculaCriteria peliculaCriteria = new PeliculaCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//peliculaCriteria.id_pelicula.eq();
		System.out.println(peliculaCriteria.uniquePelicula());
		
		System.out.println("Retrieving Director by DirectorCriteria");
		DirectorCriteria directorCriteria = new DirectorCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//directorCriteria.id_director.eq();
		System.out.println(directorCriteria.uniqueDirector());
		
		System.out.println("Retrieving Sala by SalaCriteria");
		SalaCriteria salaCriteria = new SalaCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//salaCriteria.id_sala.eq();
		System.out.println(salaCriteria.uniqueSala());
		
		System.out.println("Retrieving Funcion by FuncionCriteria");
		FuncionCriteria funcionCriteria = new FuncionCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//funcionCriteria.id_funcion.eq();
		System.out.println(funcionCriteria.uniqueFuncion());
		
		System.out.println("Retrieving Categoria by CategoriaCriteria");
		CategoriaCriteria categoriaCriteria = new CategoriaCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//categoriaCriteria.id_categoria.eq();
		System.out.println(categoriaCriteria.uniqueCategoria());
		
	}
	
	
	public static void main(String[] args) {
		try {
			RetrieveAndUpdateTallerDAOData retrieveAndUpdateTallerDAOData = new RetrieveAndUpdateTallerDAOData();
			try {
				retrieveAndUpdateTallerDAOData.retrieveAndUpdateTestData();
				//retrieveAndUpdateTallerDAOData.retrieveByCriteria();
			}
			finally {
				TallerDAOPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
