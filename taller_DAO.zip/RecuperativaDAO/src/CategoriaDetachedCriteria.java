
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class CategoriaDetachedCriteria extends AbstractORMDetachedCriteria {
	public final IntegerExpression id_categoria;
	public final StringExpression nombre_categoria;
	public final CollectionExpression id_pelicula;
	
	public CategoriaDetachedCriteria() {
		super(Categoria.class, CategoriaCriteria.class);
		id_categoria = new IntegerExpression("id_categoria", this.getDetachedCriteria());
		nombre_categoria = new StringExpression("nombre_categoria", this.getDetachedCriteria());
		id_pelicula = new CollectionExpression("ORM_Id_pelicula", this.getDetachedCriteria());
	}
	
	public CategoriaDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, CategoriaCriteria.class);
		id_categoria = new IntegerExpression("id_categoria", this.getDetachedCriteria());
		nombre_categoria = new StringExpression("nombre_categoria", this.getDetachedCriteria());
		id_pelicula = new CollectionExpression("ORM_Id_pelicula", this.getDetachedCriteria());
	}
	
	public PeliculaDetachedCriteria createId_peliculaCriteria() {
		return new PeliculaDetachedCriteria(createCriteria("ORM_Id_pelicula"));
	}
	
	public Categoria uniqueCategoria(PersistentSession session) {
		return (Categoria) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Categoria[] listCategoria(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Categoria[]) list.toArray(new Categoria[list.size()]);
	}
}

