
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
public class Funcion {
	public Funcion() {
	}
	
	private java.sql.Time hora;
	
	private int id_funcion;
	
	private Sala id_sala;
	
	private Pelicula id_pelicula;
	
	public void setHora(java.sql.Time value) {
		this.hora = value;
	}
	
	public java.sql.Time getHora() {
		return hora;
	}
	
	private void setId_funcion(int value) {
		this.id_funcion = value;
	}
	
	public int getId_funcion() {
		return id_funcion;
	}
	
	public int getORMID() {
		return getId_funcion();
	}
	
	public void setId_sala(Sala value) {
		if (this.id_sala != value) {
			Sala lid_sala = this.id_sala;
			this.id_sala = value;
			if (value != null) {
				id_sala.setFuncion(this);
			}
			if (lid_sala != null && lid_sala.getFuncion() == this) {
				lid_sala.setFuncion(null);
			}
		}
	}
	
	public Sala getId_sala() {
		return id_sala;
	}
	
	public void setId_pelicula(Pelicula value) {
		if (this.id_pelicula != value) {
			Pelicula lid_pelicula = this.id_pelicula;
			this.id_pelicula = value;
			if (value != null) {
				id_pelicula.setFuncion(this);
			}
			if (lid_pelicula != null && lid_pelicula.getFuncion() == this) {
				lid_pelicula.setFuncion(null);
			}
		}
	}
	
	public Pelicula getId_pelicula() {
		return id_pelicula;
	}
	
	public String toString() {
		return String.valueOf(getId_funcion());
	}
	
}
