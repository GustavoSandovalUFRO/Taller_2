
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class PeliculaDetachedCriteria extends AbstractORMDetachedCriteria {
	public final StringExpression titulo;
	public final IntegerExpression año;
	public final IntegerExpression id_pelicula;
	public final IntegerExpression duracion;
	public final IntegerExpression id_directorId;
	public final AssociationExpression id_director;
	public final StringExpression imagen;
	public final CollectionExpression id_categoria;
	public final IntegerExpression funcionId;
	public final AssociationExpression funcion;
	
	public PeliculaDetachedCriteria() {
		super(Pelicula.class, PeliculaCriteria.class);
		titulo = new StringExpression("titulo", this.getDetachedCriteria());
		año = new IntegerExpression("año", this.getDetachedCriteria());
		id_pelicula = new IntegerExpression("id_pelicula", this.getDetachedCriteria());
		duracion = new IntegerExpression("duracion", this.getDetachedCriteria());
		id_directorId = new IntegerExpression("id_director.id_director", this.getDetachedCriteria());
		id_director = new AssociationExpression("id_director", this.getDetachedCriteria());
		imagen = new StringExpression("imagen", this.getDetachedCriteria());
		id_categoria = new CollectionExpression("ORM_Id_categoria", this.getDetachedCriteria());
		funcionId = new IntegerExpression("funcion.id_pelicula", this.getDetachedCriteria());
		funcion = new AssociationExpression("funcion", this.getDetachedCriteria());
	}
	
	public PeliculaDetachedCriteria(DetachedCriteria aDetachedCriteria) {
		super(aDetachedCriteria, PeliculaCriteria.class);
		titulo = new StringExpression("titulo", this.getDetachedCriteria());
		año = new IntegerExpression("año", this.getDetachedCriteria());
		id_pelicula = new IntegerExpression("id_pelicula", this.getDetachedCriteria());
		duracion = new IntegerExpression("duracion", this.getDetachedCriteria());
		id_directorId = new IntegerExpression("id_director.id_director", this.getDetachedCriteria());
		id_director = new AssociationExpression("id_director", this.getDetachedCriteria());
		imagen = new StringExpression("imagen", this.getDetachedCriteria());
		id_categoria = new CollectionExpression("ORM_Id_categoria", this.getDetachedCriteria());
		funcionId = new IntegerExpression("funcion.id_pelicula", this.getDetachedCriteria());
		funcion = new AssociationExpression("funcion", this.getDetachedCriteria());
	}
	
	public DirectorDetachedCriteria createId_directorCriteria() {
		return new DirectorDetachedCriteria(createCriteria("id_director"));
	}
	
	public CategoriaDetachedCriteria createId_categoriaCriteria() {
		return new CategoriaDetachedCriteria(createCriteria("ORM_Id_categoria"));
	}
	
	public FuncionDetachedCriteria createFuncionCriteria() {
		return new FuncionDetachedCriteria(createCriteria("funcion"));
	}
	
	public Pelicula uniquePelicula(PersistentSession session) {
		return (Pelicula) super.createExecutableCriteria(session).uniqueResult();
	}
	
	public Pelicula[] listPelicula(PersistentSession session) {
		List list = super.createExecutableCriteria(session).list();
		return (Pelicula[]) list.toArray(new Pelicula[list.size()]);
	}
}

