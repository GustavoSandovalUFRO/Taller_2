/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
public class ListTallerDAOData {
	private static final int ROW_COUNT = 100;
	
	public void listTestData() throws PersistentException {
		System.out.println("Listing Pelicula...");
		Pelicula[] peliculas = PeliculaDAO.listPeliculaByQuery(null, null);
		int length = Math.min(peliculas.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(peliculas[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Director...");
		Director[] directors = DirectorDAO.listDirectorByQuery(null, null);
		length = Math.min(directors.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(directors[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Sala...");
		Sala[] salas = SalaDAO.listSalaByQuery(null, null);
		length = Math.min(salas.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(salas[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Funcion...");
		Funcion[] funcions = FuncionDAO.listFuncionByQuery(null, null);
		length = Math.min(funcions.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(funcions[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
		System.out.println("Listing Categoria...");
		Categoria[] categorias = CategoriaDAO.listCategoriaByQuery(null, null);
		length = Math.min(categorias.length, ROW_COUNT);
		for (int i = 0; i < length; i++) {
			System.out.println(categorias[i]);
		}
		System.out.println(length + " record(s) retrieved.");
		
	}
	
	public void listByCriteria() throws PersistentException {
		System.out.println("Listing Pelicula by Criteria...");
		PeliculaCriteria peliculaCriteria = new PeliculaCriteria();
		// Please uncomment the follow line and fill in parameter(s) 
		//peliculaCriteria.id_pelicula.eq();
		peliculaCriteria.setMaxResults(ROW_COUNT);
		Pelicula[] peliculas = peliculaCriteria.listPelicula();
		int length =peliculas== null ? 0 : Math.min(peliculas.length, ROW_COUNT); 
		for (int i = 0; i < length; i++) {
			 System.out.println(peliculas[i]);
		}
		System.out.println(length + " Pelicula record(s) retrieved."); 
		
		System.out.println("Listing Director by Criteria...");
		DirectorCriteria directorCriteria = new DirectorCriteria();
		// Please uncomment the follow line and fill in parameter(s) 
		//directorCriteria.id_director.eq();
		directorCriteria.setMaxResults(ROW_COUNT);
		Director[] directors = directorCriteria.listDirector();
		length =directors== null ? 0 : Math.min(directors.length, ROW_COUNT); 
		for (int i = 0; i < length; i++) {
			 System.out.println(directors[i]);
		}
		System.out.println(length + " Director record(s) retrieved."); 
		
		System.out.println("Listing Sala by Criteria...");
		SalaCriteria salaCriteria = new SalaCriteria();
		// Please uncomment the follow line and fill in parameter(s) 
		//salaCriteria.id_sala.eq();
		salaCriteria.setMaxResults(ROW_COUNT);
		Sala[] salas = salaCriteria.listSala();
		length =salas== null ? 0 : Math.min(salas.length, ROW_COUNT); 
		for (int i = 0; i < length; i++) {
			 System.out.println(salas[i]);
		}
		System.out.println(length + " Sala record(s) retrieved."); 
		
		System.out.println("Listing Funcion by Criteria...");
		FuncionCriteria funcionCriteria = new FuncionCriteria();
		// Please uncomment the follow line and fill in parameter(s) 
		//funcionCriteria.id_funcion.eq();
		funcionCriteria.setMaxResults(ROW_COUNT);
		Funcion[] funcions = funcionCriteria.listFuncion();
		length =funcions== null ? 0 : Math.min(funcions.length, ROW_COUNT); 
		for (int i = 0; i < length; i++) {
			 System.out.println(funcions[i]);
		}
		System.out.println(length + " Funcion record(s) retrieved."); 
		
		System.out.println("Listing Categoria by Criteria...");
		CategoriaCriteria categoriaCriteria = new CategoriaCriteria();
		// Please uncomment the follow line and fill in parameter(s) 
		//categoriaCriteria.id_categoria.eq();
		categoriaCriteria.setMaxResults(ROW_COUNT);
		Categoria[] categorias = categoriaCriteria.listCategoria();
		length =categorias== null ? 0 : Math.min(categorias.length, ROW_COUNT); 
		for (int i = 0; i < length; i++) {
			 System.out.println(categorias[i]);
		}
		System.out.println(length + " Categoria record(s) retrieved."); 
		
	}
	
	public static void main(String[] args) {
		try {
			ListTallerDAOData listTallerDAOData = new ListTallerDAOData();
			try {
				listTallerDAOData.listTestData();
				//listTallerDAOData.listByCriteria();
			}
			finally {
				TallerDAOPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
