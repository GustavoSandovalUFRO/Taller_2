import org.orm.util.ORMAdapter;

public class Categoria {
	public Categoria() {
	}
	
	private java.util.Set this_getSet (int key) {
		if (key == ORMConstants.KEY_CATEGORIA_ID_PELICULA) {
			return ORM_id_pelicula;
		}
		
		return null;
	}
	
	org.orm.util.ORMAdapter _ormAdapter = new org.orm.util.AbstractORMAdapter() {
		public java.util.Set getSet(int key) {
			return this_getSet(key);
		}
		
	};
	
	private int id_categoria;
	
	private String nombre_categoria;
	
	private java.util.Set ORM_id_pelicula = new java.util.HashSet();
	
	private void setId_categoria(int value) {
		this.id_categoria = value;
	}
	
	public int getId_categoria() {
		return id_categoria;
	}
	
	public int getORMID() {
		return getId_categoria();
	}
	
	public void setNombre_categoria(String value) {
		this.nombre_categoria = value;
	}
	
	public String getNombre_categoria() {
		return nombre_categoria;
	}
	
	private void setORM_Id_pelicula(java.util.Set value) {
		this.ORM_id_pelicula = value;
	}
	
	private java.util.Set getORM_Id_pelicula() {
		return ORM_id_pelicula;
	}
	
	public final PeliculaSetCollection id_pelicula = new PeliculaSetCollection(this, _ormAdapter, ORMConstants.KEY_CATEGORIA_ID_PELICULA, ORMConstants.KEY_PELICULA_ID_CATEGORIA, ORMConstants.KEY_MUL_MANY_TO_MANY);
	
	public String toString() {
		return String.valueOf(getId_categoria());
	}
	
}
