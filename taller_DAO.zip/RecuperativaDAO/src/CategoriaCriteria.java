
import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class CategoriaCriteria extends AbstractORMCriteria {
	public final IntegerExpression id_categoria;
	public final StringExpression nombre_categoria;
	public final CollectionExpression id_pelicula;
	
	public CategoriaCriteria(Criteria criteria) {
		super(criteria);
		id_categoria = new IntegerExpression("id_categoria", this);
		nombre_categoria = new StringExpression("nombre_categoria", this);
		id_pelicula = new CollectionExpression("ORM_Id_pelicula", this);
	}
	
	public CategoriaCriteria(PersistentSession session) {
		this(session.createCriteria(Categoria.class));
	}
	
	public CategoriaCriteria() throws PersistentException {
		this(TallerDAOPersistentManager.instance().getSession());
	}
	
	public PeliculaCriteria createId_peliculaCriteria() {
		return new PeliculaCriteria(createCriteria("ORM_Id_pelicula"));
	}
	
	public Categoria uniqueCategoria() {
		return (Categoria) super.uniqueResult();
	}
	
	public Categoria[] listCategoria() {
		java.util.List list = super.list();
		return (Categoria[]) list.toArray(new Categoria[list.size()]);
	}
}

