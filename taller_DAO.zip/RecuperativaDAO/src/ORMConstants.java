

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_CATEGORIA_ID_PELICULA = -2022646767;
	
	final int KEY_DIRECTOR_PELICULA = 942746060;
	
	final int KEY_FUNCION_ID_PELICULA = -1400311774;
	
	final int KEY_FUNCION_ID_SALA = -461631924;
	
	final int KEY_PELICULA_FUNCION = -1077518530;
	
	final int KEY_PELICULA_ID_CATEGORIA = 1438297813;
	
	final int KEY_PELICULA_ID_DIRECTOR = -312260182;
	
	final int KEY_SALA_FUNCION = -1806100760;
	
}
