

/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class FuncionCriteria extends AbstractORMCriteria {
	public final TimeExpression hora;
	public final IntegerExpression id_funcion;
	public final IntegerExpression id_salaId;
	public final AssociationExpression id_sala;
	public final IntegerExpression id_peliculaId;
	public final AssociationExpression id_pelicula;
	
	public FuncionCriteria(Criteria criteria) {
		super(criteria);
		hora = new TimeExpression("hora", this);
		id_funcion = new IntegerExpression("id_funcion", this);
		id_salaId = new IntegerExpression("id_sala.id_sala", this);
		id_sala = new AssociationExpression("id_sala", this);
		id_peliculaId = new IntegerExpression("id_pelicula.id_pelicula", this);
		id_pelicula = new AssociationExpression("id_pelicula", this);
	}
	
	public FuncionCriteria(PersistentSession session) {
		this(session.createCriteria(Funcion.class));
	}
	
	public FuncionCriteria() throws PersistentException {
		this(TallerDAOPersistentManager.instance().getSession());
	}
	
	public SalaCriteria createId_salaCriteria() {
		return new SalaCriteria(createCriteria("id_sala"));
	}
	
	public PeliculaCriteria createId_peliculaCriteria() {
		return new PeliculaCriteria(createCriteria("id_pelicula"));
	}
	
	public Funcion uniqueFuncion() {
		return (Funcion) super.uniqueResult();
	}
	
	public Funcion[] listFuncion() {
		java.util.List list = super.list();
		return (Funcion[]) list.toArray(new Funcion[list.size()]);
	}
}

