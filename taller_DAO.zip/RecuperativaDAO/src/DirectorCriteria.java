
/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.hibernate.Criteria;
import org.orm.PersistentException;
import org.orm.PersistentSession;
import org.orm.criteria.*;

public class DirectorCriteria extends AbstractORMCriteria {
	public final IntegerExpression id_director;
	public final StringExpression nombre;
	public final StringExpression nacionalidad;
	public final IntegerExpression peliculaId;
	public final AssociationExpression pelicula;
	
	public DirectorCriteria(Criteria criteria) {
		super(criteria);
		id_director = new IntegerExpression("id_director", this);
		nombre = new StringExpression("nombre", this);
		nacionalidad = new StringExpression("nacionalidad", this);
		peliculaId = new IntegerExpression("pelicula.id_director", this);
		pelicula = new AssociationExpression("pelicula", this);
	}
	
	public DirectorCriteria(PersistentSession session) {
		this(session.createCriteria(Director.class));
	}
	
	public DirectorCriteria() throws PersistentException {
		this(TallerDAOPersistentManager.instance().getSession());
	}
	
	public PeliculaCriteria createPeliculaCriteria() {
		return new PeliculaCriteria(createCriteria("pelicula"));
	}
	
	public Director uniqueDirector() {
		return (Director) super.uniqueResult();
	}
	
	public Director[] listDirector() {
		java.util.List list = super.list();
		return (Director[]) list.toArray(new Director[list.size()]);
	}
}

