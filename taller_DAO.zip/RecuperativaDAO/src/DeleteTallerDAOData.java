/**
 * Licensee: Gustavo(Universidad de La Frontera)
 * License Type: Academic
 */
import org.orm.*;
public class DeleteTallerDAOData {
	public void deleteTestData() throws PersistentException {
		PersistentTransaction t = TallerDAOPersistentManager.instance().getSession().beginTransaction();
		try {
			Pelicula pelicula = PeliculaDAO.loadPeliculaByQuery(null, null);
			// Delete the persistent object
			PeliculaDAO.delete(pelicula);
			Director director = DirectorDAO.loadDirectorByQuery(null, null);
			// Delete the persistent object
			DirectorDAO.delete(director);
			Sala sala = SalaDAO.loadSalaByQuery(null, null);
			// Delete the persistent object
			SalaDAO.delete(sala);
			Funcion funcion = FuncionDAO.loadFuncionByQuery(null, null);
			// Delete the persistent object
			FuncionDAO.delete(funcion);
			Categoria categoria = CategoriaDAO.loadCategoriaByQuery(null, null);
			// Delete the persistent object
			CategoriaDAO.delete(categoria);
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public static void main(String[] args) {
		try {
			DeleteTallerDAOData deleteTallerDAOData = new DeleteTallerDAOData();
			try {
				deleteTallerDAOData.deleteTestData();
			}
			finally {
				TallerDAOPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
